import marvin
MARVIN_OPEN_AI_API_KEY = "your-api-key"
OPENAI_API_KEY = "your-api-key"
image = marvin.Image(
    "https://storage.googleapis.com/kagglesdsdata/datasets/1715246/2854929/dataset/frost/3600.jpg?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=databundle-worker-v2%40kaggle-161607.iam.gserviceaccount.com%2F20240702%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20240702T112234Z&X-Goog-Expires=345600&X-Goog-SignedHeaders=host&X-Goog-Signature=182a8edf6d09a2f572c3accb471aa7f121610187189be3a65330aa590ba7f484412fe5dc70ffe9c09223f8901b0746c68c8d58a0f3e29ce54a202c46a6f5d3cb515bbc183f1061715b54212a22dd85562751fe16303eca5751ff0c1ccde3fc58683aa122d81c76fc755431856fd6d867bf2d42e24f2b6aadd255d43f7aa2b23e601ceded61f752474354ec2b3ffb210ef0b6fcee8f8e4468e0ebe795ce671a9e53d383aa582ffad269d575a4212c106ac72e9f522da4df375c5e8ca1f37d6620c1cddf8e7ff74fea5de38590bf9e5c6a083f6563c4e6a0f67f4e1d3af25be562314b1e6b5876a2007db004b83b78d0332fbdfdd4f003abbe48b8f35e76946f30"
)
image2 = marvin.Image(
    "https://storage.googleapis.com/kagglesdsdata/datasets/1715246/2854929/dataset/fogsmog/4075.jpg?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=databundle-worker-v2%40kaggle-161607.iam.gserviceaccount.com%2F20240702%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20240702T112427Z&X-Goog-Expires=345600&X-Goog-SignedHeaders=host&X-Goog-Signature=3331cac187b82d72642997f0f34851be9c64e64a12b65b55b28c6a4950ae024a466b95b5c56188321ba946a1d81f58ca0894e822ce18a782f3fb83ec354c53fbdefab6067b0b9043b3a5975315703712b159fdfb77a01fdda62a931922473a5f8a1aa9b546016fa0590a44bee158a60a772c506ec57fe1fc1893e395c310945a111f26dd214aeaf45db0be6c949526bf9aa1bc747f0fb1c2219bb311e13cf2d20ea0978469af215343b6347db117733cd87c7ab281fe4f958441cd23da64a06bcb23bc91cddd1df216e1cc87db2fc9be85066e325c6ce80b02eae824e1abf33d6cf79fbaecbef0b421252bcfd7c5542ef2ed6697d5f551fc90d399296da4a1b1"
)

frost = marvin.classify(
    image,
    labels = [
        "frost",
        "plant",
    ],
    instructions = "What is the weather in this image?"
)

fog = marvin.classify(
    image2,
    labels=[
        "fog",
        "building",
        "woman",
        "lamp",
        "power lines",
        "mask",
        "dense",
    ],
    instructions = "What is the weather in this image?"

)

print(f"The weather in the first image is {frost}")
print(f"The weather in the second image is {fog}")