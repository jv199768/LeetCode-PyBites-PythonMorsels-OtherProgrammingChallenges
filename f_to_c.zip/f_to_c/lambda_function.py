import json

def lambda_handler(event, context):
    try:
        fahrenheit = float(event['queryStringParameters']['fahrenheit'])
        celsius = (fahrenheit - 32) * 5.0/9.0
        return {
            'statusCode': 200,
            'body': json.dumps({'celsius': celsius})
        }
    except Exception as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid input'})
        }

